import React from 'react';
function OpenAccount() {
    return (
        <div className="container p-5 mb-5"> {/*p-5=padding 5px*/}
            <div className="row text-center">
                <h1 className="mt-5">Create Your CibilView Account</h1>  {/*mt-5=margin-top*/}
                <p className="mt-3">
                    Access your credit score instantly, monitor your credit report, and get personalized insights to improve your financial health.
                </p>
                <a href="/signup" className="p-2 btn btn-primary fs-5 mb-5 mt-3" style={{width:"20%", margin:"0 auto"}}>
                    Get Started for Free
                </a>
            </div>
        </div>
    );  
}

export default OpenAccount;
