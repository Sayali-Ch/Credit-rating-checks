import React from "react";

function Team() {
  return (
    <div className="container">
      {/* Header Section */}
      <div className="row p-3 text-center border-top">
        <h1 className="text-center mt-5">People</h1>
      </div>

      {/* Team Member Section */}
      <div className="row">
        {/* Image and Name Section */}
        <div className="col-12 col-md-6 p-3 text-center">
          <img className="ml-5"
            src="media/images/Founder.jpg"
            alt="Mr. John"
            style={{ borderRadius: "100%", width: "50%", height:"65%"}}
          />
          <h4 className="mt-4">Mr. John</h4>
          <h6 className="text-muted">Founder, CEO</h6>
        </div>

        {/* Description Section */}
        <div className="col-12 col-md-6 p-3 mt-3" style={{fontSize:"1.1em"}}>
          <p>
            Mr. John founded CibilView in 2025 with the mission to simplify credit 
            scoring and loan management for individuals and banks alike. His vision 
            is to make financial data transparent and empower users to make informed 
            credit decisions.
          </p>
          <p>
            He actively collaborates with financial institutions and fintech companies 
            to improve credit scoring accuracy and user experience.
          </p>
          <p>Outside work, he enjoys mentoring startups in the fintech space.</p>
          <p>Connect on: <a href="#" style={{textDecoration:"none"}}>Homepage</a> / <a href="#" style={{textDecoration:"none"}}>LinkedIn</a> / <a href="#" style={{textDecoration:"none"}}>Twitter</a></p>
        </div>
      </div>
    </div>
  );
}

export default Team;
