import React from "react";

function Hero() {
  return (
    <div className="container">
      <div className="row p-5 text-center mt-5 mb-5">
        <h1 className="fs-4 ">
          We pioneered seamless credit scoring for individuals in India.
          <br />
          Now, we are transforming access to loans with technology.{" "}
        </h1>
      </div>
      <div
        className="row p-5 mt-5 border-top text-muted "
        style={{ lineHeight: "1.8", fontSize: "1.2em" }}
      >
        <div className="col-6 p-5">
          <p>
            Our journey began on Oct 20th, 2025, with a mission to simplify the
            loan application process and empower users to understand their
            credit health. We chose the name CibilView, reflecting our commitment
            to transparency and reliable credit insights. <br />
            <br />
            Today, our intelligent scoring models and user-friendly platform have
            enabled thousands of users to track their credit score, manage
            applications, and make informed financial decisions daily.
          </p>
        </div>
        <div className="col-6 p-5">
          <p>
            In addition, we provide educational resources and community support
            to help individuals improve financial literacy and maintain good
            credit practices.
            <br />
            <br />
            Our platform also collaborates with banks and fintech companies to
            deliver accurate credit reports and actionable insights.
            <br />
            <br />
            Stay updated with the latest in credit scoring and financial
            wellness through our{" "}
            <a href="#" style={{ textDecoration: "none" }}>
              blog
            </a>{" "}
            or check out the media coverage on our innovative approach.
          </p>
        </div>
      </div>
    </div>
  );
}

export default Hero;
