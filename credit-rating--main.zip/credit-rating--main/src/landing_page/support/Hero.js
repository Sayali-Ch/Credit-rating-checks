import React from 'react';

function Hero() {
    return ( 
        /*classname container fluid is used to occupy the entire screen for that div*/
        <section id="supportHero" style={{ padding: "2rem" }}>
            <div id="supportWrapper" style={{ padding: "2rem" }}>
                <h5 style={{fontWeight:"bold"}}>CibilView Support Portal</h5>
                <a href="#" style={{fontWeight:"bold"}}>Track Support Tickets</a>
            </div>
            <div className="row mb-5">
                <div className="col-6 support-content">
                    <h1 className="fs-3">
                        Search for answers or browse topics to <br/>
                        create a support ticket for your credit profile or loan application
                    </h1>
                    <input placeholder="Eg. how do I check my credit score, why was my loan rejected, how to update documents..." />
                    <br/><br/>
                    <a href="#" style={{marginRight:"32px"}}>Track Profile Verification</a>
                    <a href="#" style={{marginRight:"32px"}}>Track Loan Application</a>
                    <a href="#" style={{marginRight:"43px"}}>Check Credit Score</a>
                    <br/>
                    <a href="#" style={{marginRight:"20px"}}>CibilView User Guide</a>
                </div>
                <div className="col-6 support-content" style={{fontWeight:"bold"}}>
                    <h4>Featured</h4>
                    <a href="#">1. Understanding Credit Score Factors - 2025</a>
                    <br/><br/>
                    <a href="#">2. How Loan Decisions are Made by CibilView</a>
                </div>
            </div>
        </section>
    );
}

export default Hero;
