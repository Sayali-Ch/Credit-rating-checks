import React from 'react';

function CreateTicket() {
    return (  
        <div className="container">
            <div className="row p-2 mt-5">
                <h5 className="fs-4 text-muted">To create a support ticket, select a relevant topic</h5>

                <div className="col-4 p-3 mt-5 mb-3">
                    <h5 className=""><i class="fa fa-plus-circle" aria-hidden="true"></i> Account & Verification</h5>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Open New CibilView Account</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Profile Verification</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Upload / Replace Documents</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Identity & Address Proof</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>PAN & Aadhaar Linking</a>
                    <br/>
                </div>

                <div className="col-4 p-3 mt-5 mb-3">
                    <h5> <i class="fa-solid fa-user"></i> Your CibilView Profile</h5>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Login Credentials</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Update Personal Info</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Financial Details</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Credit Score Overview</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Loan Application Status</a>
                    <br/>
                </div>

                <div className="col-4 p-3 mt-5 mb-3">
                    <h5> <i class="fa-solid fa-chart-column"></i> Analytics & Reports</h5>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Credit Score Trends</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Loan Application Insights</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Repayment Behavior</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Debt-to-Income Ratio</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Download Reports</a>
                    <br/>
                </div>
            </div>

            <div className="row p-2 mb-5">
                <div className="col-4 p-3 mb-3">
                    <h5><i class="fa-regular fa-credit-card"></i> Loans & Applications</h5>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Apply for New Loan</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Track Existing Applications</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>EMI & Repayment Details</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Loan History</a>
                    <br/>
                </div>

                <div className="col-4 p-3 mb-3">
                    <h5><i class="fa-regular fa-circle"></i> Notifications & Alerts</h5>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Loan Status Updates</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Credit Score Alerts</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Document Verification Notifications</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>General Announcements</a>
                    <br/>
                </div>

                <div className="col-4 p-3 mb-3">
                    <h5><i class="fa-solid fa-money-bill"></i> Resources & Support</h5>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Help Center</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>FAQs</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Contact Support</a>
                    <br/>
                    <a href="#" style={{textDecoration:"none",lineHeight:"2.5"}}>Learning Resources</a>
                    <br/>
                </div>
            </div>
        </div>
    );
}

export default CreateTicket;
