import React from 'react';

function Hero() {
  return (
    <div className="container py-5">
      <div className="row align-items-center">
        <div className="col-md-6">
          <h1 className="display-4 fw-bold">Our Pricing</h1>
          <p className="lead">
            Transparent pricing with no hidden charges. Find the perfect plan for your needs.
          </p>
        </div>
      </div>
    </div>
  );
}

export default Hero;
