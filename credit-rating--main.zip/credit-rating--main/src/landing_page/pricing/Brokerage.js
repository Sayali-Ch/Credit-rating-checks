import React from 'react';

function Brokerage() {
  return (
    <div className="container py-5">
      <div className="row">
        <div className="col-md-4">
          <div className="card mb-4">
            <div className="card-body">
              <h3 className="card-title">Basic</h3>
              <h2 className="card-subtitle mb-2 text-muted">Free</h2>
              <ul className="list-unstyled mt-3 mb-4">
                <li>Basic credit score check</li>
                <li>Monthly report</li>
                <li>Email support</li>
              </ul>
              <button className="btn btn-primary w-100">Get Started</button>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card mb-4">
            <div className="card-body">
              <h3 className="card-title">Pro</h3>
              <h2 className="card-subtitle mb-2 text-muted">₹199/month</h2>
              <ul className="list-unstyled mt-3 mb-4">
                <li>Advanced credit monitoring</li>
                <li>Weekly reports</li>
                <li>Priority support</li>
              </ul>
              <button className="btn btn-primary w-100">Subscribe</button>
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card mb-4">
            <div className="card-body">
              <h3 className="card-title">Enterprise</h3>
              <h2 className="card-subtitle mb-2 text-muted">Custom</h2>
              <ul className="list-unstyled mt-3 mb-4">
                <li>Custom solutions</li>
                <li>API access</li>
                <li>24/7 support</li>
              </ul>
              <button className="btn btn-primary w-100">Contact Us</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Brokerage;
