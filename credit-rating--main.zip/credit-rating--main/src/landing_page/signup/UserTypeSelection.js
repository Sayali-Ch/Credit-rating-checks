import React from 'react';
import { useNavigate } from 'react-router-dom';
import './signup.css';

function UserTypeSelection() {
  const navigate = useNavigate();

  const handleUserTypeSelection = (type) => {
    if (type === 'customer') {
      navigate('/customer-login');
    } else {
      navigate('/employee-login');
    }
  };

  return (
    <div className="page_wrapper">
      <div className="form_container">
        <h2>Select User Type</h2>
        <div className="button-group">
          <button 
            className="type-button" 
            onClick={() => handleUserTypeSelection('customer')}
          >
            Customer
          </button>
          <button 
            className="type-button" 
            onClick={() => handleUserTypeSelection('employee')}
          >
            Employee
          </button>
        </div>
      </div>
    </div>
  );
}

export default UserTypeSelection;
