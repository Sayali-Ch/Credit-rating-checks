import React from 'react';

function Hero() {
    return ( 
        <div className="container border-bottom mb-5">
            <div className="text-center mt-5">
                <h1>Welcome to CibilView</h1>
                <h3 className="text-muted mt-3 fs-4">Know your credit score instantly</h3>
                <p className="mt-3 mb-5">
                    Get started by <a href="#" style={{textDecoration:"none"}}>checking your credit report</a> 
                    <i className="fa fa-long-arrow-right" aria-hidden="true" style={{color:"blue"}}></i>
                </p>
            </div>
        </div>
    );
}

export default Hero;
