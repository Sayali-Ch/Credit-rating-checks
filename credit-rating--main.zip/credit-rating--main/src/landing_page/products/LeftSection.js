import React from 'react';

function LeftSection({ imageURL, productName, productDescription, tryDemo, learnMore, googlePlay, appStore }) {
    return (
        <div className="container my-5"> {/* Use consistent vertical spacing */}
            <div className="row align-items-center"> {/* Ensure vertical alignment */}
                <div className="col-6 p-4"> {/* Adjust padding */}
                    <img src={process.env.PUBLIC_URL + "/media/images/admindashboard.jpg"} alt={productName} style={{ width: "100%", height: "auto" }} />

                </div>
                <div className="col-6 p-4"> {/* Adjust padding */}
                    <h1>{productName}</h1>
                    <p>{productDescription}</p>
                    <div className="mb-3">
                        <a href={tryDemo}>
                            Check Your Credit Score <i className="fa fa-long-arrow-right" style={{ color: "blue" }}></i>
                        </a>
                        <a href={learnMore} style={{ marginLeft: "20px" }}>
                            Learn How It Works <i className="fa fa-long-arrow-right" style={{ color: "blue" }}></i>
                        </a>
                    </div>
                    <div className="no-underline">
                        <a href={googlePlay}>
                            <img src={process.env.PUBLIC_URL + "/media/images/googlePlayBadge.svg"} alt="Google Play" style={{ marginRight: "15px" }} />
                        </a>
                        <a href={appStore}>
                            <img src={process.env.PUBLIC_URL + "/media/images/appStoreBadge.svg"} alt="App Store" />
                        </a>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default LeftSection;
