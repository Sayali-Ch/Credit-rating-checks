import React from "react";
import Hero from "./Hero";
import LeftSection from "./LeftSection";
import Universe from "./Universe";
import RightSection from "./RightSection";

function ProductsPage() {
  return (
    <>
      <Hero />

      <LeftSection
        imageURL="media/images/kite.png"
        productName="Credit Score Checker"
        productDescription="Instantly check your Cibil credit score and get a detailed report with insights into your credit history. Access it anytime on Android and iOS devices."
        tryDemo=""
        learnMore=" "
        googlePlay=""
        appStore=""
      />

      <RightSection 
        imageURL="media/images/console.png"
        productName="Loan Eligibility Dashboard"
        productDescription="See which loans you are eligible for based on your credit history. Get personalized recommendations and detailed insights to make informed decisions."
        learnMore="" 
      />
      
      <LeftSection
        imageURL="media/images/coin.png"
        productName="Credit Insights"
        productDescription="Understand the factors affecting your credit score. Get tips on improving your score, managing debts, and maintaining healthy financial habits on mobile devices."
        tryDemo=""
        learnMore=" "
        googlePlay=""
        appStore=""
      />

      <RightSection
        imageURL="media/images/kiteconnect.png"
        productName="Cibil API"
        productDescription="Integrate credit score checks and loan eligibility insights into your apps or platforms with our simple and secure HTTP/JSON APIs."
        learnMore="" 
      />
      
     

      <p className="text-center fs-4">
        Want to know more about our technology stack? Check out the{" "}
        <a href="/blog" style={{textDecoration:"none"}}>CibilView blog.</a>
      </p>

      <Universe/>
    </>
  );
}

export default ProductsPage;
