import React from 'react';

function Universe() {
    return (
        <div className="container">
            {/* Title Section */}
            <div className="row text-center mb-5">
                <div className="col-12 mt-5">
                    
                </div>
            </div>

            
            
        </div>
    );
}

export default Universe;
