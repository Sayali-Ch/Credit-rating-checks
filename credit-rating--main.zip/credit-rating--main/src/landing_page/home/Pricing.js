
import React from 'react';

function Pricing() {
    return ( 
        <div className="container mb-5">
            <div className="row">
                {/* Text Section */}
                <div className="col-4">
                    <h1 className='mb-3 fs-2'>Transparent Pricing</h1>
                    <p>CibilView offers free credit score checks and affordable premium insights. No hidden charges, no surprises.</p>
                    <a href="/signup" style={{textDecoration:'none'}}>Get Started</a>
                </div>

                <div className="col-2"></div> {/* Spacer */}

                {/* Pricing Cards */}
                <div className="col-6 mb-5">
                    <div className="row text-center">
                        <div className="col p-3 border">
                            <h1 className="mb-3">₹0</h1>
                            <p>Free credit score<br/>and basic report</p>
                        </div>
                        <div className="col p-3 border">
                            <h1 className="mb-3">₹199</h1>
                            <p>Detailed credit report<br/>with personalized insights</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Pricing;
