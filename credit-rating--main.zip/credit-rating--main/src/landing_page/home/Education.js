import React from 'react';

function Education() {
    return (
        <div className="container mt-5">
            <div className="row">
                <div className="col-6">
                    <img 
                        src="/media/images/education.svg" 
                        alt="Financial Education" 
                        style={{ width: "93%" }} 
                        className="mb-5" 
                    />
                </div>
                <div className="col-6">
                    <h1 className="fs-2 mb-3">Free and Open Financial Education</h1>
                    <p>
                        Learn about credit scores, loan eligibility, and personal finance with CibilView's educational resources. 
                        Our content helps you make informed financial decisions and improve your credit health.
                    </p>
                    <a href="#" style={{ textDecoration: "none" }}>
                        Learn More<i className="fa-solid fa-arrow-right" style={{ marginLeft: "5px" }}></i>
                    </a>

                    <p className="mt-5">
                        Join the CibilView Community to discuss credit-related queries, share tips, and get expert advice to manage your finances better.
                    </p>
                    <a href="#" style={{ textDecoration: "none" }}>
                        Community<i className="fa-solid fa-arrow-right" style={{ marginLeft: "5px" }}></i>
                    </a>
                </div>
            </div>
        </div>
    );
}

export default Education;
