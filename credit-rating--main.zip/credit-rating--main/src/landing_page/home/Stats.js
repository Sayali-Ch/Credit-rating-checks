import React from 'react';

function Stats() {
    return ( 
        <div className="container p-3">
            <div className="row p-5">
                {/* Text Section */}
                <div className="col-6 p-5">
                    <h1 className='fs-2 mb-5' style={{textAlign:"left"}}>Trust with Confidence</h1>

                    <h2 className='fs-4' style={{textAlign:"left"}}>Customer-first always</h2>
                    <p className="text-muted">
                        Millions of users rely on CibilView to get accurate credit scores and actionable insights for smarter financial decisions.
                    </p>

                    <h2 className='fs-4' style={{textAlign:"left"}}>Transparent & Safe</h2>
                    <p className="text-muted">
                        No spam, hidden charges, or gimmicks. Only secure, high-quality credit monitoring tools you can trust.
                    </p>

                    <h2 className='fs-4' style={{textAlign:"left"}}>CibilView Ecosystem</h2>
                    <p className="text-muted">
                        More than a credit score app – we offer personalized credit tips, loan eligibility insights, and guidance to improve your financial health.
                    </p>

                    <h2 className='fs-4' style={{textAlign:"left"}}>Take control of your finances</h2>
                    <p className="text-muted">
                        With features like alerts, personalized suggestions, and financial planning tools, CibilView helps you make smarter money decisions.
                    </p>
                </div>

                {/* Image Section */}
                <div className="col-6 p-5">
                    <img src="/media/images/creditEcosystem.png" style={{width:"90%"}} alt="CibilView Ecosystem"/>
                    <div className="text-center mt-4">
                        
                        
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Stats;
