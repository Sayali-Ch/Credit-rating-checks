import React from 'react';

function Hero() {
    return ( 
        <div className="container p-5 mb-5"> {/* Padding and bottom margin */}
            <div className="row text-center">
                <img 
                    src='/media/images/homeHero.png' 
                    alt="CibilView Hero" 
                    className="mb-5" 
                /> {/* Hero illustration */}
                <h1 className="mt-5">Check Your Credit Score Instantly</h1>  
                <p>Get detailed credit reports, monitor your credit health, and understand loan eligibility with CibilView.</p>
                <a 
                    href="/signup" 
                    className="p-2 btn btn-primary fs-5 mb-5" 
                    style={{ width: "20%", margin: "0 auto" }}
                >
                    Signup for Free
                </a>
            </div>
        </div>
    );
}

export default Hero;
