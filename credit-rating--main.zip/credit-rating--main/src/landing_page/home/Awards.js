import React from 'react';

function Awards() {
    return (
        <div className="container mt-5">
            <div className="row">
                {/* Image Column */}
                <div className="col-6 p-5">
                    <img 
                        src="/media/images/admindashboard.jpg" 
                        alt="CibilView Dashboard" 
                        className="img-fluid" 
                    />
                </div>
                {/* Text and List Column */}
                <div className="col-6 p-5 mt-5">
                    <h1>Trusted by Thousands of Users</h1>
                    <p className="mb-5">
                        Over 2+ million users rely on CibilView for accurate credit scores and loan eligibility insights. Our platform helps users track, manage, and improve their credit health effortlessly.
                    </p>
                    {/* Two-column list */}
                    <div className="row">
                        <div className="col-6 mb-2">
                            <ul className="list-unstyled">
                                <li><p>Instant Credit Score Check</p></li>
                                <li><p>Personal Loan Eligibility</p></li>
                                <li><p>Credit Monitoring Alerts</p></li>
                            </ul>
                        </div>
                        <div className="col-6 mb-2">
                            <ul className="list-unstyled">
                                <li><p>Track Multiple Credit Cards</p></li>
                                <li><p>Loan Pre-Approval Insights</p></li>
                                <li><p>Financial Health Reports</p></li>
                            </ul>
                        </div>
                    </div>
                    {/* Press / Recognition Logos */}
                    <img 
                        src="/media/images/pressLogos.png" 
                        alt="Press logos" 
                        style={{ width: "90%" }} 
                        className="mt-2 p-3 img-fluid" 
                    />
                </div>
            </div>
        </div>
    );
}

export default Awards;
