import React from 'react';

function LoanApplications() {
  return (
    <div style={{ padding: "2rem", backgroundColor: "#f8f9fa" }}>
      <div style={{ maxWidth: "1200px", margin: "0 auto", backgroundColor: "white", borderRadius: "8px", padding: "2rem" }}>
        <div style={{ marginBottom: "1.5rem" }}>
          <h2 style={{ marginBottom: "0.5rem" }}>Loan Applications</h2>
          <span style={{ color: "#6c757d" }}>Recent applications sorted by submission date (newest first)</span>
        </div>
        <div style={{ overflowX: "auto" }}>
          <table>
            <thead>
              <tr>
                <th>APPLICANT</th>
                <th>CREDIT SCORE</th>
                <th>LOAN TYPE</th>
                <th>REQUIRED</th>
                <th>STATUS</th>
                <th>ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              {/* Sample data - replace with actual data */}
              <tr>
                <td style={{ padding: "1rem" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
                    <div style={{ width: "32px", height: "32px", backgroundColor: "#007bff", color: "white", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center" }}>A</div>
                    <div>Alex Williams</div>
                  </div>
                </td>
                <td style={{ padding: "1rem" }}>720</td>
                <td style={{ padding: "1rem" }}>Home Loan</td>
                <td style={{ padding: "1rem" }}>800K</td>
                <td style={{ padding: "1rem" }}><span style={{ background: "#28a745", color: "white", padding: "0.25rem 0.75rem", borderRadius: "1rem", fontSize: "0.875rem" }}>Approved</span></td>
                <td style={{ padding: "1rem" }}><button style={{ background: "none", border: "1px solid #007bff", color: "#007bff", padding: "0.25rem 0.75rem", borderRadius: "4px", cursor: "pointer" }}>View Details</button></td>
              </tr>
              {/* Add more rows as needed */}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default LoanApplications;
