import React from 'react';
function Footer() {
  return (
    <footer className="site-footer" style={{ backgroundColor: "rgb(245,245,245)" }}> 
      <div className="container border-top mt-5">
        <div className="row mt-5">
          <div className="col">
            <img src="media/images/logo.png" style={{ width: "190px",height:"70px",borderRadius:"10px"}} />
            <br />
            <p>© 2023 - 2025, CibilView Ltd.<br />All rights reserved.</p>
          </div>
          <div className="col">
            <p>Company</p>
            <a href="#" style={{ textDecoration: "none", color: "black", opacity: "0.5", display: "block", marginBottom: "8px" }}>About</a>
            <a href="#" style={{ textDecoration: "none", color: "black", opacity: "0.5", display: "block", marginBottom: "8px" }}>Services</a>
            <a href="#" style={{ textDecoration: "none", color: "black", opacity: "0.5", display: "block", marginBottom: "8px" }}>Pricing</a>
            <a href="#" style={{ textDecoration: "none", color: "black", opacity: "0.5", display: "block", marginBottom: "8px" }}>Referral Program</a>
            <a href="#" style={{ textDecoration: "none", color: "black", opacity: "0.5", display: "block", marginBottom: "8px" }}>Careers</a>
            <a href="#" style={{ textDecoration: "none", color: "black", opacity: "0.5", display: "block", marginBottom: "8px" }}>cibilview.com</a>
            <a href="#" style={{ textDecoration: "none", color: "black", opacity: "0.5", display: "block", marginBottom: "8px" }}>Press & Media</a>
            <a href="#" style={{ textDecoration: "none", color: "black", opacity: "0.5", display: "block", marginBottom: "8px" }}>CibilView Cares (CSR)</a>
          </div>
          <div className="col">
            <p>Support</p>
            <a href="#" style={{ textDecoration: "none", color: "black", opacity: "0.5", display: "block", marginBottom: "8px" }}>Contact</a>
            <a href="#" style={{ textDecoration: "none", color: "black", opacity: "0.5", display: "block", marginBottom: "8px" }}>Support Portal</a>
            <a href="#" style={{ textDecoration: "none", color: "black", opacity: "0.5", display: "block", marginBottom: "8px" }}>Blog</a>
            <a href="#" style={{ textDecoration: "none", color: "black", opacity: "0.5", display: "block", marginBottom: "8px" }}>Help & Resources</a>
            <a href="#" style={{ textDecoration: "none", color: "black", opacity: "0.5", display: "block", marginBottom: "8px" }}>Free Demo</a>
          </div>
          <div className="col">
            <p>Account</p>
            <a href="#" style={{ textDecoration: "none", color: "black", opacity: "0.5", display: "block", marginBottom: "8px" }}>Create Account</a>
            <a href="#" style={{ textDecoration: "none", color: "black", opacity: "0.5", display: "block", marginBottom: "8px" }}>Update Profile</a>
            <a href="#" style={{ textDecoration: "none", color: "black", opacity: "0.5", display: "block", marginBottom: "8px" }}>Check Credit Score</a>
          </div>
        </div>
        <div className="mt-5 text-muted" style={{ fontSize: "13px" }}>
          <p>
            CibilView Ltd.: Credit Information Provider registered under RBI / Credit Bureaus. Registered Address: #153/154, 4th Cross, Dollars Colony, Opp. Clarence Public School, J.P Nagar 4th Phase, Mumbai - 560078, Maharashtra , India. For complaints regarding credit reports, write to support@cibilview.com. Please read the Risk Disclosure and Terms before using our services.
          </p>
          <p>
            Procedure to file a complaint on <a href="#">Credit Bureau Portal:</a> Register on the portal with Name, PAN, Address, Mobile Number, E-mail ID. Benefits: Quick communication and redressal of grievances.
          </p>
          <a href="#">Online Dispute Resolution | Grievances Redressal Mechanism</a>
          <p>
            Credit scores are indicative of your creditworthiness; use responsibly and understand terms before applying for loans.
          </p>
        </div>
        <div className="footer-graveyard-links text-center" style={{ display: "flex", justifyContent: "center", gap: "20px", flexWrap: "wrap", fontSize:"14px"}}>
          <a href="https://www.cibil.com" style={{ textDecoration: "none", color: "black", opacity: "0.5", marginBottom:"20px" }}>CIBIL</a>
          <a href="https://www.equifax.co.in" style={{ textDecoration: "none", color: "black", opacity: "0.5", marginBottom:"20px" }}>Equifax</a>
          <a href="https://www.crifhighmark.com" style={{ textDecoration: "none", color: "black", opacity: "0.5", marginBottom:"20px" }}>CRIF Highmark</a>
          <a href="#" style={{ textDecoration: "none", color: "black", opacity: "0.5", marginBottom:"20px"}}>Terms &amp; Conditions</a>
          <a href="#" style={{ textDecoration: "none", color: "black", opacity: "0.5", marginBottom:"20px" }}>Privacy Policy</a>
          <a href="#" style={{ textDecoration: "none", color: "black", opacity: "0.5", marginBottom:"20px" }}>Disclosure</a>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
