import React from 'react';
import './features.css';

function FeaturesPage() {
  return (
    <div className="features-page">
      <div className="container py-5">
        <h1 className="text-center mb-5">Our Features</h1>
        
        <div className="row g-4">
          <div className="col-md-4">
            <div className="card h-100">
              <div className="card-body">
                <h3 className="card-title">Zero Account Charges</h3>
                <p className="card-text">
                  Open your free trading and demat account with zero account maintenance charges.
                </p>
              </div>
            </div>
          </div>

          <div className="col-md-4">
            <div className="card h-100">
              <div className="card-body">
                <h3 className="card-title">Fast & Secure</h3>
                <p className="card-text">
                  Lightning-fast execution with secure and reliable trading platform.
                </p>
              </div>
            </div>
          </div>

          <div className="col-md-4">
            <div className="card h-100">
              <div className="card-body">
                <h3 className="card-title">Advanced Charts</h3>
                <p className="card-text">
                  Advanced charting platform with multiple technical indicators and drawing tools.
                </p>
              </div>
            </div>
          </div>

          <div className="col-md-4">
            <div className="card h-100">
              <div className="card-body">
                <h3 className="card-title">Real-time Analytics</h3>
                <p className="card-text">
                  Get real-time market data and analytics to make informed trading decisions.
                </p>
              </div>
            </div>
          </div>

          <div className="col-md-4">
            <div className="card h-100">
              <div className="card-body">
                <h3 className="card-title">Mobile Trading</h3>
                <p className="card-text">
                  Trade anywhere, anytime with our powerful mobile trading app.
                </p>
              </div>
            </div>
          </div>

          <div className="col-md-4">
            <div className="card h-100">
              <div className="card-body">
                <h3 className="card-title">Expert Support</h3>
                <p className="card-text">
                  Get expert support from our dedicated team of trading professionals.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default FeaturesPage;
